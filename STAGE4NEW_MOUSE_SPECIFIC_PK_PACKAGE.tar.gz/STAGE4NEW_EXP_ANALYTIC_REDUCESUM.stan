// FINAL STAGE 4 REBUILD: built-in GQ, original-scale log_lik, diagnostic-only repair-factor check.

functions {
  // ------------------------------
  // RT-only reduced exponential system
  // ------------------------------
  vector rt_reduced_ode(
      real t,
      vector y,
      vector theta,
      real P_start,
      real D_start,
      real t_start
  ) {
    real r      = theta[1];
    real delta  = theta[2];
    real beta_a = theta[3];
    real beta_q = theta[4];
    real k_rep  = theta[5];

    real A = y[1];
    real dt = t - t_start;
    real repair_factor = exp(-k_rep * dt);
    real D = D_start * repair_factor;

    real log_P_ratio =
      r * dt
      - ((beta_a + beta_q) * D_start / k_rep)
        * (1 - repair_factor);

    real P = P_start * exp(log_P_ratio);

    vector[2] dydt;
    dydt[1] = beta_a * D * P - delta * A;
    // V = P + Q + A, hence V' = r*P - delta*A
    dydt[2] = r * P - delta * A;
    return dydt;
  }

  // ------------------------------
  // Combination PK + RT-damage + tumour system
  //
  // State:
  // y[1] = C1  drug absorption/gut compartment
  // y[2] = C2  central drug compartment
  // y[3] = D   RT-induced DNA damage
  // y[4] = P   proliferating tumour
  // y[5] = A   dying/apoptotic tumour
  // y[6] = V   total measured tumour volume = P + Q + A
  //
  // Veliparib acts ONLY through repair inhibition:
  // D' = -k_rep * (1 - k_repi*C2) * D.
  // Therefore when RT is absent and D=0, drug cannot affect tumour growth.
  // ------------------------------
  // Exact between-event PK propagation for the linear two-compartment subsystem.
  real pk_c1_exact(real dt, real C1_0, real k_abs) {
    return C1_0 * exp(-k_abs * dt);
  }

  real pk_c2_exact(real dt, real C1_0, real C2_0, real k_abs, real k_cl) {
    if (fabs(k_abs - k_cl) > 1e-8)
      return C2_0 * exp(-k_cl * dt)
        + k_abs * C1_0 * (exp(-k_cl * dt) - exp(-k_abs * dt)) / (k_abs - k_cl);
    return exp(-k_cl * dt) * (C2_0 + k_abs * C1_0 * dt);
  }

  real pk_int_c2_exact(real dt, real C1_0, real C2_0, real k_abs, real k_cl) {
    real term0 = C2_0 * (1 - exp(-k_cl * dt)) / k_cl;
    if (fabs(k_abs - k_cl) > 1e-8)
      return term0 + k_abs * C1_0 / (k_abs - k_cl)
        * ((1 - exp(-k_cl * dt)) / k_cl - (1 - exp(-k_abs * dt)) / k_abs);
    return term0 + C1_0 * (1 - exp(-k_cl * dt) * (1 + k_cl * dt)) / k_cl;
  }

  real damage_exact(real dt, real D_0, real C1_0, real C2_0,
                    real k_rep, real k_repi, real k_abs, real k_cl) {
    real int_c2 = pk_int_c2_exact(dt, C1_0, C2_0, k_abs, k_cl);
    return D_0 * exp(-k_rep * dt + k_rep * k_repi * int_c2);
  }

  // Reduced combination tumour system. PK (C1,C2) and DNA damage D are
  // propagated analytically between treatment events; only P,A,V are numerical states.
  vector combo_reduced_ode(real t, vector y, vector theta,
                           real C1_0, real C2_0, real D_0, real t_start) {
    real r       = theta[1];
    real delta   = theta[2];
    real beta_a  = theta[3];
    real beta_q  = theta[4];
    real k_rep   = theta[5];
    real k_abs   = theta[6];
    real k_cl    = theta[7];
    real k_repi  = theta[8];
    real dt = t - t_start;
    real D = damage_exact(dt, D_0, C1_0, C2_0, k_rep, k_repi, k_abs, k_cl);
    real P = y[1];
    real A = y[2];
    real V = y[3];
    real growth = r * P;
    vector[3] dydt;
    dydt[1] = growth - (beta_a + beta_q) * D * P;
    dydt[2] = beta_a * D * P - delta * A;
    dydt[3] = growth - delta * A;
    return dydt;
  }


  // ------------------------------
  // Mouse-sliced log likelihood for reduce_sum
  //
  // group:
  // 1 = untreated control
  // 2 = drug only (mechanistic consistency arm)
  // 3 = RT only
  // 4 = drug + RT combination
  // ------------------------------
  real partial_sum_mouse(
      array[] int mouse_slice,
      int start,
      int end,

      array[] int group,
      array[] int rt_index,
      array[] int comb_index,

      array[] int mouse_obs_start,
      array[] int mouse_obs_end,
      vector obs_time,
      vector volume,

      array[] int mouse_segment_start,
      array[] int mouse_segment_end,
      array[] real segment_start_time,
      array[] real segment_drug_dose,
      array[] real segment_rt_dose,
      array[] int solve_start,
      array[] int solve_end,
      array[] real solve_time,
      array[] int solve_obs_index,

      vector baseline_volume,

      vector V0_mouse,
      vector r_mouse,

      vector delta_rt,
      vector alpha_rt,
      vector beta_a_rt,
      vector beta_q_rt,
      vector k_rep_rt,

      vector k_abs_comb,
      vector k_cl_comb,
      vector k_repi_comb,

      real sigma,
      data real rel_tol,
      data real abs_tol,
      data int max_num_steps
  ) {
    real lp = 0;

    for (ii in 1:size(mouse_slice)) {
      int m = mouse_slice[ii];

      // Earliest volume measurement for each mouse is modelled,
      // not treated as a fixed exact initial condition.
      lp += normal_lpdf(
        log(baseline_volume[m]) |
        log(V0_mouse[m]),
        sigma
      );

      // ----------------------------------------
      // Control and drug-only arms:
      // no RT => D(t)=0 exactly.
      // Drug-only is therefore the Stage-3 consistency check:
      // same tumour law as control, while drug PK is not estimated
      // from an arm where it cannot influence tumour volume.
      // ----------------------------------------
      if (group[m] <= 2) {
        if (mouse_obs_start[m] > 0) {
          for (n in mouse_obs_start[m]:mouse_obs_end[m]) {
            real mu_log =
              log(V0_mouse[m]) + r_mouse[m] * obs_time[n];

            lp += normal_lpdf(
              log(volume[n]) |
              mu_log,
              sigma
            );
          }
        }
      }

      // ----------------------------------------
      // RT-only arm: preserve Stage-2 reduced
      // exponential implementation.
      // ----------------------------------------
      else if (group[m] == 3) {
        int q = rt_index[m];

        vector[2] y_current;
        vector[5] theta_rt;

        real P_current = V0_mouse[m];
        real D_current = 0;

        y_current[1] = 0;
        y_current[2] = V0_mouse[m];

        theta_rt[1] = r_mouse[m];
        theta_rt[2] = delta_rt[q];
        theta_rt[3] = beta_a_rt[q];
        theta_rt[4] = beta_q_rt[q];
        theta_rt[5] = k_rep_rt[q];

        for (s in mouse_segment_start[m]:mouse_segment_end[m]) {
          real interval_start = segment_start_time[s];

          // RT event at segment start.
          D_current += alpha_rt[q] * segment_rt_dose[s];

          {
            int n_times = solve_end[s] - solve_start[s] + 1;
            array[n_times] real solve_times;
            array[n_times] vector[2] y_solution;

            for (j in 1:n_times)
              solve_times[j] = solve_time[solve_start[s] + j - 1];

            y_solution =
              ode_rk45_tol(
                rt_reduced_ode,
                y_current,
                interval_start,
                solve_times,
                rel_tol,
                abs_tol,
                max_num_steps,
                theta_rt,
                P_current,
                D_current,
                interval_start
              );

            for (j in 1:n_times) {
              int global_solve_index = solve_start[s] + j - 1;
              int observation_index = solve_obs_index[global_solve_index];

              if (observation_index > 0) {
                real V_pred = fmax(y_solution[j][2], 1e-10);

                lp += normal_lpdf(
                  log(volume[observation_index]) |
                  log(V_pred),
                  sigma
                );
              }
            }

            {
              real dt_end = solve_times[n_times] - interval_start;
              real repair_factor_end =
                exp(-k_rep_rt[q] * dt_end);

              real log_P_ratio_end =
                r_mouse[m] * dt_end
                - (
                    (beta_a_rt[q] + beta_q_rt[q])
                    * D_current
                    / k_rep_rt[q]
                  )
                  * (1 - repair_factor_end);

              P_current *= exp(log_P_ratio_end);
              y_current = y_solution[n_times];
              D_current *= repair_factor_end;
            }
          }
        }
      }

      // ----------------------------------------
      // Combination arm:
      // drug changes repair of RT-induced damage.
      // ----------------------------------------
    else {
        int q = rt_index[m];
        int c = comb_index[m];
        real k_abs_m = k_abs_comb[c];
        real k_cl_m = k_cl_comb[c];
        real k_repi_m = k_repi_comb[c];
        vector[3] y_current;
        vector[8] theta_combo;
        real C1_current = 0;
        real C2_current = 0;
        real D_current = 0;

        y_current[1] = V0_mouse[m]; // P
        y_current[2] = 0;           // A
        y_current[3] = V0_mouse[m]; // V

        theta_combo[1] = r_mouse[m];
        theta_combo[2] = delta_rt[q];
        theta_combo[3] = beta_a_rt[q];
        theta_combo[4] = beta_q_rt[q];
        theta_combo[5] = k_rep_rt[q];
        theta_combo[6] = k_abs_m;
        theta_combo[7] = k_cl_m;
        theta_combo[8] = k_repi_m;

        for (s in mouse_segment_start[m]:mouse_segment_end[m]) {
          real interval_start = segment_start_time[s];
          real C1_start; real C2_start; real D_start;
          C1_current += segment_drug_dose[s];
          D_current += alpha_rt[q] * segment_rt_dose[s];
          C1_start = C1_current; C2_start = C2_current; D_start = D_current;

          {
            int n_times = solve_end[s] - solve_start[s] + 1;
            array[n_times] real solve_times;
            array[n_times] vector[3] y_solution;
            for (j in 1:n_times) solve_times[j] = solve_time[solve_start[s] + j - 1];
            y_solution = ode_rk45_tol(combo_reduced_ode, y_current, interval_start, solve_times,
                                      rel_tol, abs_tol, max_num_steps, theta_combo,
                                      C1_start, C2_start, D_start, interval_start);
            for (j in 1:n_times) {
              int global_solve_index = solve_start[s] + j - 1;
              int observation_index = solve_obs_index[global_solve_index];
              if (observation_index > 0) {
              real V_pred = fmax(y_solution[j][3], 1e-10);
              lp += normal_lpdf(log(volume[observation_index]) | log(V_pred), sigma);
              }
            }
            {
              real dt_end = solve_times[n_times] - interval_start;
              y_current = y_solution[n_times];
              C1_current = pk_c1_exact(dt_end, C1_start, k_abs_m);
              C2_current = pk_c2_exact(dt_end, C1_start, C2_start, k_abs_m, k_cl_m);
              D_current = damage_exact(dt_end, D_start, C1_start, C2_start,
                                       k_rep_rt[q], k_repi_m, k_abs_m, k_cl_m);
            }
          }
        }
      }
    }

    return lp;
  }
}

data {
  int<lower=1> M;
  int<lower=1> N_rt;
  int<lower=1> N_comb;

  // Mouse groups and the contiguous RT-parameter index
  // used only for mice with RT exposure.
  array[M] int<lower=1, upper=4> group;
  array[M] int<lower=0, upper=N_rt> rt_index;
  array[M] int<lower=0, upper=N_comb> comb_index;

  // Post-baseline observations, globally ordered by mouse/time.
  int<lower=1> N_obs;
  vector<lower=0>[N_obs] obs_time;
  vector<lower=0>[N_obs] volume;
  array[M] int<lower=0, upper=N_obs> mouse_obs_start;
  array[M] int<lower=0, upper=N_obs> mouse_obs_end;

  // Baseline observations.
  vector<lower=0>[M] baseline_volume;

  // Segmented treatment/ODE table for RT-bearing mice only.
  int<lower=1> N_segments;
  int<lower=1> N_solve;

  array[N_segments] real<lower=0> segment_start_time;
  array[N_segments] real<lower=0> segment_drug_dose;
  array[N_segments] real<lower=0> segment_rt_dose;

  array[N_segments] int<lower=1, upper=N_solve> solve_start;
  array[N_segments] int<lower=1, upper=N_solve> solve_end;

  array[N_solve] real<lower=0> solve_time;
  array[N_solve] int<lower=0, upper=N_obs> solve_obs_index;

  array[M] int<lower=0, upper=N_segments> mouse_segment_start;
  array[M] int<lower=0, upper=N_segments> mouse_segment_end;

  // ODE controls.
  real<lower=0> rel_tol;
  real<lower=0> abs_tol;
  int<lower=1> max_num_steps;

  // reduce_sum controls.
  int<lower=1> grainsize;
}

transformed data {
  array[M] int mouse_seq;
  for (m in 1:M)
    mouse_seq[m] = m;
}

parameters {
  // Baseline growth hierarchy for all 78 mice.
  real logV0_pop;
  real logr_pop;

  real<lower=0> sigma_logV0;
  real<lower=0> sigma_logr;

  vector[M] z_logV0;
  vector[M] z_logr;

  // Provisional Stage-2 MFULL hierarchy, now defined
  // only for the RT-bearing mice (RT-only + combination).
  real logdelta_pop;
  real logalpha_pop;
  real logbeta_a_pop;
  real logbeta_q_pop;
  real logk_rep_pop;

  real<lower=0> sigma_logdelta;
  real<lower=0> sigma_logalpha;
  real<lower=0> sigma_logbeta_a;
  real<lower=0> sigma_logbeta_q;
  real<lower=0> sigma_logk_rep;

  vector[N_rt] z_logdelta;
  vector[N_rt] z_logalpha;
  vector[N_rt] z_logbeta_a;
  vector[N_rt] z_logbeta_q;
  vector[N_rt] z_logk_rep;

  // Combination-arm PK/repair-inhibition hierarchy.
  // Each combination mouse has its own value; population-level
  // hyperparameters provide partial pooling across the nine mice.
  real logk_abs_pop;
  real logk_cl_pop;
  real logk_repi_pop;

  real<lower=0> sigma_logk_abs;
  real<lower=0> sigma_logk_cl;
  real<lower=0> sigma_logk_repi;

  vector[N_comb] z_logk_abs;
  vector[N_comb] z_logk_cl;
  vector[N_comb] z_logk_repi;

  real<lower=0> sigma;
}

transformed parameters {
  vector[M] V0_mouse =
    exp(logV0_pop + sigma_logV0 * z_logV0);

  vector[M] r_mouse =
    exp(logr_pop + sigma_logr * z_logr);

  vector[N_rt] delta_rt =
    exp(logdelta_pop + sigma_logdelta * z_logdelta);

  vector[N_rt] alpha_rt =
    exp(logalpha_pop + sigma_logalpha * z_logalpha);

  vector[N_rt] beta_a_rt =
    exp(logbeta_a_pop + sigma_logbeta_a * z_logbeta_a);

  vector[N_rt] beta_q_rt =
    exp(logbeta_q_pop + sigma_logbeta_q * z_logbeta_q);

  vector[N_rt] k_rep_rt =
    exp(logk_rep_pop + sigma_logk_rep * z_logk_rep);

  vector<lower=0>[N_comb] k_abs_comb =
    exp(logk_abs_pop + sigma_logk_abs * z_logk_abs);

  vector<lower=0>[N_comb] k_cl_comb =
    exp(logk_cl_pop + sigma_logk_cl * z_logk_cl);

  vector<lower=0>[N_comb] k_repi_comb =
    exp(logk_repi_pop + sigma_logk_repi * z_logk_repi);
}

model {
  // Stage-1 exponential growth priors.
  logV0_pop ~ normal(log(30), 0.5);
  logr_pop ~ normal(log(0.3), 0.5);

  sigma_logV0 ~ normal(0, 0.5);
  sigma_logr ~ normal(0, 0.5);

  z_logV0 ~ std_normal();
  z_logr ~ std_normal();

  // Stage-2 mechanistic prior centres, on day scale.
  logdelta_pop ~ normal(log(1.2), 0.5);
  logalpha_pop ~ normal(log(0.9), 0.5);
  logbeta_a_pop ~ normal(log(26.4), 0.5);
  logbeta_q_pop ~ normal(log(4.8), 0.5);
  logk_rep_pop ~ normal(log(86.4), 0.5);

  sigma_logdelta ~ normal(0, 0.5);
  sigma_logalpha ~ normal(0, 0.5);
  sigma_logbeta_a ~ normal(0, 0.5);
  sigma_logbeta_q ~ normal(0, 0.5);
  sigma_logk_rep ~ normal(0, 0.5);

  z_logdelta ~ std_normal();
  z_logalpha ~ std_normal();
  z_logbeta_a ~ std_normal();
  z_logbeta_q ~ std_normal();
  z_logk_rep ~ std_normal();

  // Supplied reference model centres:
  // k_abs = 4/hour -> 96/day
  // k_cl  = 0.8/hour -> 19.2/day
  // effective repair-inhibition coefficient = 4/100 = 0.04.
  //
  // These population-level centres are intentionally informative because
  // there are no measured drug concentrations in the experimental dataset.
  logk_abs_pop ~ normal(log(96), 0.35);
  logk_cl_pop ~ normal(log(19.2), 0.35);
  logk_repi_pop ~ normal(log(0.04), 0.35);

  sigma_logk_abs ~ normal(0, 0.5);
  sigma_logk_cl ~ normal(0, 0.5);
  sigma_logk_repi ~ normal(0, 0.5);

  z_logk_abs ~ std_normal();
  z_logk_cl ~ std_normal();
  z_logk_repi ~ std_normal();

  sigma ~ normal(0, 0.5);

  target += reduce_sum(
    partial_sum_mouse,
    mouse_seq,
    grainsize,

    group,
    rt_index,
    comb_index,

    mouse_obs_start,
    mouse_obs_end,
    obs_time,
    volume,

    mouse_segment_start,
    mouse_segment_end,
    segment_start_time,
    segment_drug_dose,
    segment_rt_dose,
    solve_start,
    solve_end,
    solve_time,
    solve_obs_index,

    baseline_volume,

    V0_mouse,
    r_mouse,

    delta_rt,
    alpha_rt,
    beta_a_rt,
    beta_q_rt,
    k_rep_rt,

    k_abs_comb,
    k_cl_comb,
    k_repi_comb,

    sigma,
    rel_tol,
    abs_tol,
    max_num_steps
  );
}

generated quantities {
  // Posterior predictive quantities evaluated from the already-fitted Stage-4 posterior draws.
  // Baseline and post-baseline observations are kept separate because that is the exact
  // likelihood structure used in the fitted model: M=78 baselines + N_obs=530 post-baseline.
  vector[M] mu_log_baseline;
  vector[M] mu_baseline;
  vector[M] y_rep_baseline;
  vector[M] log_lik_baseline;

  vector[N_obs] mu_log_post = rep_vector(0.0, N_obs);
  vector[N_obs] mu_post = rep_vector(0.0, N_obs);
  vector[N_obs] y_rep_post = rep_vector(0.0, N_obs);
  vector[N_obs] log_lik_post = rep_vector(0.0, N_obs);

  // Diagnostic only: evaluated at combination-arm solver output times.
  // These quantities NEVER reject draws or remove observations.
  vector[N_obs] repair_factor_post = rep_vector(1.0, N_obs);
  real min_repair_factor_checked = 1.0;
  int negative_repair_factor_count = 0;

  // Baseline likelihood: identical to the fitted model.
  for (m in 1:M) {
    mu_log_baseline[m] = log(V0_mouse[m]);
    mu_baseline[m] = V0_mouse[m];
    y_rep_baseline[m] = lognormal_rng(mu_log_baseline[m], sigma);
    log_lik_baseline[m] = lognormal_lpdf(
      baseline_volume[m] | mu_log_baseline[m], sigma
    );
  }

  // Post-baseline likelihood/predictions, using exactly the fitted model branches.
  for (m in 1:M) {
    if (group[m] <= 2) {
      if (mouse_obs_start[m] > 0) {
        for (n in mouse_obs_start[m]:mouse_obs_end[m]) {
          real mu_log = log(V0_mouse[m]) + r_mouse[m] * obs_time[n];
          mu_log_post[n] = mu_log;
          mu_post[n] = exp(mu_log);
          y_rep_post[n] = lognormal_rng(mu_log, sigma);
          log_lik_post[n] = lognormal_lpdf(volume[n] | mu_log, sigma);
        }
      }
    }
    else if (group[m] == 3) {
      int q = rt_index[m];
      vector[2] y_current;
      vector[5] theta_rt;
      real P_current = V0_mouse[m];
      real D_current = 0;

      y_current[1] = 0;
      y_current[2] = V0_mouse[m];

      theta_rt[1] = r_mouse[m];
      theta_rt[2] = delta_rt[q];
      theta_rt[3] = beta_a_rt[q];
      theta_rt[4] = beta_q_rt[q];
      theta_rt[5] = k_rep_rt[q];

      for (s in mouse_segment_start[m]:mouse_segment_end[m]) {
        real interval_start = segment_start_time[s];
        D_current += alpha_rt[q] * segment_rt_dose[s];

        {
          int n_times = solve_end[s] - solve_start[s] + 1;
          array[n_times] real solve_times;
          array[n_times] vector[2] y_solution;

          for (j in 1:n_times)
            solve_times[j] = solve_time[solve_start[s] + j - 1];

          y_solution = ode_rk45_tol(
            rt_reduced_ode, y_current, interval_start, solve_times,
            rel_tol, abs_tol, max_num_steps, theta_rt,
            P_current, D_current, interval_start
          );

          for (j in 1:n_times) {
            int global_solve_index = solve_start[s] + j - 1;
            int observation_index = solve_obs_index[global_solve_index];
            if (observation_index > 0) {
              real V_pred = fmax(y_solution[j][2], 1e-10);
              real mu_log = log(V_pred);
              mu_log_post[observation_index] = mu_log;
              mu_post[observation_index] = V_pred;
              y_rep_post[observation_index] = lognormal_rng(mu_log, sigma);
              log_lik_post[observation_index] = lognormal_lpdf(
                volume[observation_index] | mu_log, sigma
              );
            }
          }

          {
            real dt_end = solve_times[n_times] - interval_start;
            real repair_factor_end = exp(-k_rep_rt[q] * dt_end);
            real log_P_ratio_end =
              r_mouse[m] * dt_end
              - ((beta_a_rt[q] + beta_q_rt[q]) * D_current / k_rep_rt[q])
                * (1 - repair_factor_end);
            P_current *= exp(log_P_ratio_end);
            y_current = y_solution[n_times];
            D_current *= repair_factor_end;
          }
        }
      }
    }
    else {
        int q = rt_index[m];
        int c = comb_index[m];
        real k_abs_m = k_abs_comb[c];
        real k_cl_m = k_cl_comb[c];
        real k_repi_m = k_repi_comb[c];
        vector[3] y_current;
        vector[8] theta_combo;
        real C1_current = 0;
        real C2_current = 0;
        real D_current = 0;

        y_current[1] = V0_mouse[m]; // P
        y_current[2] = 0;           // A
        y_current[3] = V0_mouse[m]; // V

        theta_combo[1] = r_mouse[m];
        theta_combo[2] = delta_rt[q];
        theta_combo[3] = beta_a_rt[q];
        theta_combo[4] = beta_q_rt[q];
        theta_combo[5] = k_rep_rt[q];
        theta_combo[6] = k_abs_m;
        theta_combo[7] = k_cl_m;
        theta_combo[8] = k_repi_m;

        for (s in mouse_segment_start[m]:mouse_segment_end[m]) {
          real interval_start = segment_start_time[s];
          real C1_start; real C2_start; real D_start;
          C1_current += segment_drug_dose[s];
          D_current += alpha_rt[q] * segment_rt_dose[s];
          C1_start = C1_current; C2_start = C2_current; D_start = D_current;

          {
            int n_times = solve_end[s] - solve_start[s] + 1;
            array[n_times] real solve_times;
            array[n_times] vector[3] y_solution;
            for (j in 1:n_times) solve_times[j] = solve_time[solve_start[s] + j - 1];
            y_solution = ode_rk45_tol(combo_reduced_ode, y_current, interval_start, solve_times,
                                      rel_tol, abs_tol, max_num_steps, theta_combo,
                                      C1_start, C2_start, D_start, interval_start);
            for (j in 1:n_times) {
              int global_solve_index = solve_start[s] + j - 1;
              int observation_index = solve_obs_index[global_solve_index];
              if (observation_index > 0) {
              real V_pred = fmax(y_solution[j][3], 1e-10);
              real dt_j = solve_times[j] - interval_start;
              real C2_here = pk_c2_exact(dt_j, C1_start, C2_start, k_abs_m, k_cl_m);
              real repair_factor_here = 1 - k_repi_m * C2_here;
              repair_factor_post[observation_index] = repair_factor_here;
              min_repair_factor_checked = fmin(min_repair_factor_checked, repair_factor_here);
              if (repair_factor_here < 0) negative_repair_factor_count += 1;
              real mu_log = log(V_pred);
              mu_log_post[observation_index] = mu_log;
              mu_post[observation_index] = V_pred;
              y_rep_post[observation_index] = lognormal_rng(mu_log, sigma);
              log_lik_post[observation_index] = lognormal_lpdf(volume[observation_index] | mu_log, sigma);
              }
            }
            {
              real dt_end = solve_times[n_times] - interval_start;
              y_current = y_solution[n_times];
              C1_current = pk_c1_exact(dt_end, C1_start, k_abs_m);
              C2_current = pk_c2_exact(dt_end, C1_start, C2_start, k_abs_m, k_cl_m);
              D_current = damage_exact(dt_end, D_start, C1_start, C2_start,
                                       k_rep_rt[q], k_repi_m, k_abs_m, k_cl_m);
            }
          }
        }
      }
  }
}
