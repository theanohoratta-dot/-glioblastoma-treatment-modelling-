#!/bin/bash
#$ -S /bin/bash
#$ -cwd
#$ -l h_rt=48:00:00
#$ -l mem=4G
#$ -pe smp 16
#$ -N STG4NEW_EXP
#$ -o STG4NEW_EXP.o$JOB_ID
#$ -e STG4NEW_EXP.e$JOB_ID

set -euo pipefail

module -f unload compilers mpi gcc-libs || true
module load r/4.5.1-openblas/gnu-10.2.0

export STAN_NUM_THREADS=4
export STAGE4_MODE=full

cd "$HOME/Scratch/dissertation"

echo "Start: $(date)"
echo "Host: $(hostname)"
echo "NSLOTS=${NSLOTS:-unset}"
echo "STAN_NUM_THREADS=$STAN_NUM_THREADS"

Rscript STAGE4NEW_EXP_ANALYTIC_REDUCESUM.R

status=$?
echo "R exit status: $status"
echo "End: $(date)"
exit $status
