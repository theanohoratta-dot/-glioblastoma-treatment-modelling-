# FINAL STAGE 4 ANALYTIC REBUILD driver. Uses built-in generated quantities in Stan.

############################################################
# STAGE 4: JOINT CONTROL + DRUG + RT + COMBINATION MODEL
# Provisional Stage-2 MFULL hierarchy
# Exponential growth law
# Mouse-sliced reduce_sum parallelisation
#
# IMPORTANT BIOLOGICAL/MECHANISTIC POINT
# --------------------------------------
# Stage 3 was a consistency check. In the supplied mechanism,
# veliparib inhibits repair of RT-induced DNA damage. With no RT
# and D(0)=0, D(t)=0 exactly, so drug-only tumour growth reduces
# to untreated growth. In Stage 4, veliparib DOES act in the
# combination mice because RT creates D>0, after which C2 modifies
# the repair term:
#
#   dD/dt = -k_rep * (1 - k_repi*C2) * D.
#
# Thus the combination arm is what can inform repair inhibition.
#
# Parallelisation:
#   reduce_sum slices over mice.
#   Full run: 4 chains x 4 threads/chain = 16 requested cores.
############################################################

suppressPackageStartupMessages({
  library(cmdstanr)
  library(dplyr)
  library(tidyr)
  library(posterior)
})

set.seed(123)

MODE <- Sys.getenv("STAGE4_MODE", unset = "syntax")
if (!MODE %in% c("syntax", "smoke", "full")) {
  stop("STAGE4_MODE must be one of: syntax, smoke, full")
}

cat("STAGE4_MODE =", MODE, "\n")

############################################################
# 1. Paths
############################################################

data_candidates <- c(
  "data/lemassonParpi.csv",
  "lemassonParpi.csv",
  "lemassonParpi (2)(20260907-110340).csv"
)

data_path <- data_candidates[file.exists(data_candidates)][1]
if (is.na(data_path)) {
  stop(
    "Could not find lemassonParpi.csv. Expected one of: ",
    paste(data_candidates, collapse = ", ")
  )
}

stan_file <- "STAGE4NEW_EXP_ANALYTIC_REDUCESUM.stan"

if (!file.exists(stan_file)) {
  stop("Stan file not found: ", stan_file)
}

results_dir <- "results/stage4new_combination_mfull_exp_reducesum"
csv_dir <- file.path(results_dir, "cmdstan_csv")
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(csv_dir, recursive = TRUE, showWarnings = FALSE)

############################################################
# 2. Read and validate full experimental dataset
############################################################

data <- read.csv(data_path)

required_cols <- c(
  "mouse", "time", "volume", "observation",
  "dose", "modality", "study"
)

stopifnot(all(required_cols %in% names(data)))

data <- data %>%
  mutate(
    time_days = time / 24
  )

stopifnot(
  all(is.finite(data$time_days)),
  all(data$time_days >= 0)
)

mouse_treatment <- data %>%
  group_by(mouse) %>%
  summarise(
    has_drug = any(modality == 1, na.rm = TRUE),
    has_rt = any(modality == 2, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    group = case_when(
      !has_drug & !has_rt ~ 1L,  # control
       has_drug & !has_rt ~ 2L,  # drug only
      !has_drug &  has_rt ~ 3L,  # RT only
       has_drug &  has_rt ~ 4L   # combination
    ),
    group_name = c(
      "control", "drug_only", "rt_only", "combination"
    )[group]
  ) %>%
  arrange(mouse) %>%
  mutate(mouse_id = row_number())

stopifnot(
  nrow(mouse_treatment) == 78,
  identical(mouse_treatment$mouse_id, seq_len(nrow(mouse_treatment)))
)

group_counts <- mouse_treatment %>%
  count(group, group_name, name = "n_mice")

print(group_counts)

# These counts are explicit checks against the supplied project dataset.
stopifnot(
  group_counts$n_mice[group_counts$group == 1] == 23,
  group_counts$n_mice[group_counts$group == 2] == 13,
  group_counts$n_mice[group_counts$group == 3] == 33,
  group_counts$n_mice[group_counts$group == 4] == 9
)

write.csv(
  group_counts,
  file.path(results_dir, "group_counts.csv"),
  row.names = FALSE
)

############################################################
# 3. Observation table and baseline definition
############################################################

obs <- data %>%
  filter(observation == 1) %>%
  left_join(
    mouse_treatment %>%
      select(mouse, mouse_id, group, group_name),
    by = "mouse"
  ) %>%
  arrange(mouse_id, time_days)

stopifnot(
  nrow(obs) > 0,
  all(!is.na(obs$mouse_id)),
  all(is.finite(obs$volume)),
  all(obs$volume > 0)
)

duplicate_obs <- obs %>%
  count(mouse, time_days) %>%
  filter(n > 1)

print(duplicate_obs)
stopifnot(nrow(duplicate_obs) == 0)

baseline <- obs %>%
  group_by(mouse, mouse_id, group, group_name) %>%
  slice_min(time_days, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  arrange(mouse_id) %>%
  transmute(
    mouse,
    mouse_id,
    group,
    group_name,
    t0 = time_days,
    baseline_volume = volume
  )

stopifnot(
  nrow(baseline) == 78,
  all(baseline$t0 == 0),
  all(baseline$baseline_volume > 0)
)

obs_post <- obs %>%
  left_join(
    baseline %>% select(mouse, t0),
    by = "mouse"
  ) %>%
  filter(time_days > t0) %>%
  select(-t0) %>%
  arrange(mouse_id, time_days) %>%
  mutate(obs_index = row_number())

N_obs <- nrow(obs_post)

mouse_obs_index <- tibble(mouse_id = seq_len(78)) %>%
  left_join(
    obs_post %>%
      group_by(mouse_id) %>%
      summarise(
        mouse_obs_start = min(obs_index),
        mouse_obs_end = max(obs_index),
        n_postbaseline_obs = n(),
        .groups = "drop"
      ),
    by = "mouse_id"
  ) %>%
  mutate(
    mouse_obs_start = replace_na(mouse_obs_start, 0L),
    mouse_obs_end = replace_na(mouse_obs_end, 0L),
    n_postbaseline_obs = replace_na(n_postbaseline_obs, 0L)
  ) %>%
  arrange(mouse_id)

stopifnot(all(mouse_obs_index$n_postbaseline_obs > 0))

############################################################
# 4. Treatment events
############################################################

events <- data %>%
  filter(modality %in% c(1, 2)) %>%
  left_join(
    mouse_treatment %>%
      select(mouse, mouse_id, group, group_name),
    by = "mouse"
  ) %>%
  arrange(mouse_id, time_days, modality)

stopifnot(
  all(!is.na(events$mouse_id)),
  all(!is.na(events$dose)),
  all(is.finite(events$dose)),
  all(events$dose > 0)
)

# No observation is allowed to coincide with a treatment event in this
# implementation. The actual supplied dataset should satisfy this.
same_time_obs_event <- inner_join(
  obs %>% select(mouse, time_days),
  events %>% select(mouse, time_days, modality, dose),
  by = c("mouse", "time_days"),
  relationship = "many-to-many"
)

print(same_time_obs_event)
stopifnot(nrow(same_time_obs_event) == 0)

# Collapse any same-time administrations by modality.
events_collapsed <- events %>%
  group_by(mouse, mouse_id, group, group_name, time_days) %>%
  summarise(
    drug_dose = sum(dose[modality == 1], na.rm = TRUE),
    rt_dose = sum(dose[modality == 2], na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(
    drug_dose = ifelse(is.finite(drug_dose), drug_dose, 0),
    rt_dose = ifelse(is.finite(rt_dose), rt_dose, 0)
  ) %>%
  arrange(mouse_id, time_days)

############################################################
# 5. Explicit Stage-3 mechanistic consistency record
############################################################

drug_only_check <- mouse_treatment %>%
  filter(group == 2)

stopifnot(nrow(drug_only_check) == 13)

consistency_record <- data.frame(
  statement = c(
    "Drug-only mice contain drug administrations",
    "Drug-only mice contain no RT administrations",
    "With D(0)=0 and no RT, D(t)=0 exactly",
    "Therefore drug-only tumour dynamics reduce to untreated growth",
    "In combination mice, RT creates D>0 and veliparib modifies DNA-damage repair"
  ),
  verified = c(TRUE, TRUE, TRUE, TRUE, TRUE)
)

write.csv(
  consistency_record,
  file.path(results_dir, "stage3_to_stage4_mechanistic_consistency.csv"),
  row.names = FALSE
)

############################################################
# 6. RT-bearing mouse index for MFULL mechanistic hierarchy
############################################################

rt_bearing <- mouse_treatment %>%
  filter(group %in% c(3L, 4L)) %>%
  arrange(mouse_id) %>%
  mutate(rt_index = row_number())

N_rt <- nrow(rt_bearing)
stopifnot(N_rt == 42)

mouse_treatment <- mouse_treatment %>%
  left_join(
    rt_bearing %>% select(mouse_id, rt_index),
    by = "mouse_id"
  ) %>%
  mutate(
    rt_index = replace_na(rt_index, 0L)
  ) %>%
  arrange(mouse_id)

# Contiguous index for combination mice only. These are the only mice
# for which drug PK/repair-inhibition parameters enter the tumour likelihood.
combination_mice <- mouse_treatment %>%
  filter(group == 4L) %>%
  arrange(mouse_id) %>%
  mutate(comb_index = row_number())

N_comb <- nrow(combination_mice)
stopifnot(N_comb == 9)

mouse_treatment <- mouse_treatment %>%
  left_join(
    combination_mice %>% select(mouse_id, comb_index),
    by = "mouse_id"
  ) %>%
  mutate(
    comb_index = replace_na(comb_index, 0L)
  ) %>%
  arrange(mouse_id)

############################################################
# 7. Build segmented solver tables for RT-bearing mice
#
# Segment starts:
#   t0=0 and each treatment-event time before final observation.
#
# Event doses at a segment start are applied instantaneously BEFORE
# integrating forward from that segment start.
#
# Solver output times:
#   all observations in (segment_start, segment_end]
#   plus segment_end for exact carry-forward.
############################################################

segment_list <- list()
solve_list <- list()

segment_counter <- 0L
solve_counter <- 0L

for (m in rt_bearing$mouse_id) {

  mouse_current <- mouse_treatment$mouse[mouse_treatment$mouse_id == m]
  t0_current <- baseline$t0[baseline$mouse_id == m]

  obs_current <- obs_post %>%
    filter(mouse_id == m) %>%
    arrange(time_days)

  stopifnot(nrow(obs_current) > 0)

  final_time_current <- max(obs_current$time_days)

  event_current <- events_collapsed %>%
    filter(
      mouse_id == m,
      time_days <= final_time_current
    ) %>%
    arrange(time_days)

  segment_start_times <- sort(unique(c(
    t0_current,
    event_current$time_days[
      event_current$time_days < final_time_current
    ]
  )))

  for (s_local in seq_along(segment_start_times)) {

    segment_start <- segment_start_times[s_local]

    if (s_local < length(segment_start_times)) {
      segment_end <- segment_start_times[s_local + 1L]
    } else {
      segment_end <- final_time_current
    }

    if (segment_end <= segment_start) next

    drug_at_start <- sum(
      event_current$drug_dose[
        event_current$time_days == segment_start
      ]
    )

    rt_at_start <- sum(
      event_current$rt_dose[
        event_current$time_days == segment_start
      ]
    )

    obs_segment <- obs_current %>%
      filter(
        time_days > segment_start,
        time_days <= segment_end
      )

    output_times <- sort(unique(c(
      obs_segment$time_days,
      segment_end
    )))

    stopifnot(
      length(output_times) > 0,
      all(output_times > segment_start),
      all(output_times <= segment_end)
    )

    output_obs_index <- match(
      output_times,
      obs_segment$time_days
    )

    output_obs_index[is.na(output_obs_index)] <- 0L

    positive <- output_obs_index > 0L
    output_obs_index[positive] <-
      obs_segment$obs_index[
        output_obs_index[positive]
      ]

    segment_counter <- segment_counter + 1L

    solve_start_current <- solve_counter + 1L

    solve_list[[segment_counter]] <- data.frame(
      segment_id = segment_counter,
      time_days = output_times,
      obs_index = as.integer(output_obs_index)
    )

    solve_counter <- solve_counter + length(output_times)

    segment_list[[segment_counter]] <- data.frame(
      segment_id = segment_counter,
      mouse = mouse_current,
      mouse_id = m,
      segment_start_time = segment_start,
      segment_end_time = segment_end,
      drug_dose_at_start = drug_at_start,
      rt_dose_at_start = rt_at_start,
      solve_start = solve_start_current,
      solve_end = solve_counter
    )
  }
}

segment_table <- bind_rows(segment_list)
solve_table <- bind_rows(solve_list)

stopifnot(
  nrow(segment_table) > 0,
  nrow(solve_table) > 0
)

segment_index_by_mouse <- tibble(mouse_id = seq_len(78)) %>%
  left_join(
    segment_table %>%
      group_by(mouse_id) %>%
      summarise(
        mouse_segment_start = min(segment_id),
        mouse_segment_end = max(segment_id),
        n_segments = n(),
        .groups = "drop"
      ),
    by = "mouse_id"
  ) %>%
  mutate(
    mouse_segment_start =
      replace_na(mouse_segment_start, 0L),
    mouse_segment_end =
      replace_na(mouse_segment_end, 0L),
    n_segments =
      replace_na(n_segments, 0L)
  ) %>%
  arrange(mouse_id)

stopifnot(
  all(
    segment_index_by_mouse$n_segments[
      mouse_treatment$group %in% c(1L, 2L)
    ] == 0
  ),
  all(
    segment_index_by_mouse$n_segments[
      mouse_treatment$group %in% c(3L, 4L)
    ] > 0
  )
)

# Every post-baseline observation from an RT-bearing mouse must be
# mapped exactly once by the solver table.
rt_obs_indices <- obs_post %>%
  filter(group %in% c(3L, 4L)) %>%
  pull(obs_index)

mapped_rt_obs_indices <-
  solve_table$obs_index[solve_table$obs_index > 0]

stopifnot(
  length(mapped_rt_obs_indices) == length(rt_obs_indices),
  length(unique(mapped_rt_obs_indices)) == length(rt_obs_indices),
  setequal(mapped_rt_obs_indices, rt_obs_indices)
)

# Control and drug-only observations are handled analytically and
# must therefore NOT be solver-mapped.
analytic_obs_indices <- obs_post %>%
  filter(group %in% c(1L, 2L)) %>%
  pull(obs_index)

stopifnot(
  length(intersect(
    mapped_rt_obs_indices,
    analytic_obs_indices
  )) == 0
)

############################################################
# 8. Dataset/schedule summaries
############################################################

dataset_summary <- data.frame(
  n_mice = nrow(mouse_treatment),
  n_control = sum(mouse_treatment$group == 1),
  n_drug_only = sum(mouse_treatment$group == 2),
  n_rt_only = sum(mouse_treatment$group == 3),
  n_combination = sum(mouse_treatment$group == 4),
  n_observations_total = nrow(obs),
  n_baseline_observations = nrow(baseline),
  n_postbaseline_observations = nrow(obs_post),
  n_drug_events = sum(events$modality == 1),
  n_rt_events = sum(events$modality == 2),
  n_rt_bearing_mice = N_rt,
  n_solver_segments = nrow(segment_table),
  n_solver_output_times = nrow(solve_table)
)

print(dataset_summary)

write.csv(
  dataset_summary,
  file.path(results_dir, "stage4_dataset_summary.csv"),
  row.names = FALSE
)

write.csv(
  mouse_treatment,
  file.path(results_dir, "mouse_group_lookup.csv"),
  row.names = FALSE
)

write.csv(
  segment_table,
  file.path(results_dir, "stan_segment_table.csv"),
  row.names = FALSE
)

write.csv(
  solve_table,
  file.path(results_dir, "stan_solve_table.csv"),
  row.names = FALSE
)

############################################################
# 9. Stan data
############################################################

M <- nrow(mouse_treatment)

stan_data <- list(
  M = M,
  N_rt = N_rt,
  N_comb = N_comb,

  group = as.integer(mouse_treatment$group),
  rt_index = as.integer(mouse_treatment$rt_index),
  comb_index = as.integer(mouse_treatment$comb_index),

  N_obs = N_obs,
  obs_time = as.numeric(obs_post$time_days),
  volume = as.numeric(obs_post$volume),
  mouse_obs_start =
    as.integer(mouse_obs_index$mouse_obs_start),
  mouse_obs_end =
    as.integer(mouse_obs_index$mouse_obs_end),

  baseline_volume =
    as.numeric(baseline$baseline_volume),

  N_segments = nrow(segment_table),
  N_solve = nrow(solve_table),

  segment_start_time =
    as.numeric(segment_table$segment_start_time),
  segment_drug_dose =
    as.numeric(segment_table$drug_dose_at_start),
  segment_rt_dose =
    as.numeric(segment_table$rt_dose_at_start),

  solve_start =
    as.integer(segment_table$solve_start),
  solve_end =
    as.integer(segment_table$solve_end),

  solve_time =
    as.numeric(solve_table$time_days),
  solve_obs_index =
    as.integer(solve_table$obs_index),

  mouse_segment_start =
    as.integer(segment_index_by_mouse$mouse_segment_start),
  mouse_segment_end =
    as.integer(segment_index_by_mouse$mouse_segment_end),

  rel_tol = 1e-6,
  abs_tol = 1e-6,
  max_num_steps = 100000L,

  grainsize = 1L
)

############################################################
# 10. Stan syntax check
############################################################

cat("\nChecking Stage-4 Stan syntax...\n")

syntax_model <- cmdstan_model(
  stan_file,
  compile = FALSE
)

syntax_model$check_syntax()

cat("STAGE 4 STAN SYNTAX CHECK PASSED.\n")

if (MODE == "syntax") {
  cat("\nSTAGE 4 SYNTAX/DATA VALIDATION COMPLETE.\n")
  quit(save = "no", status = 0)
}

############################################################
# 11. Threaded compilation
############################################################

cat("\nCompiling Stage-4 model with Stan threading enabled...\n")

mod <- cmdstan_model(
  stan_file,
  cpp_options = list(stan_threads = TRUE)
)

############################################################
# 12. Initial values
############################################################

stage4_init <- function() {
  list(
    logV0_pop = log(30),
    logr_pop = log(0.3),

    sigma_logV0 = 0.15,
    sigma_logr = 0.10,

    z_logV0 = rep(0, M),
    z_logr = rep(0, M),

    logdelta_pop = log(1.2),
    logalpha_pop = log(0.9),
    logbeta_a_pop = log(26.4),
    logbeta_q_pop = log(4.8),
    logk_rep_pop = log(86.4),

    sigma_logdelta = 0.30,
    sigma_logalpha = 0.10,
    sigma_logbeta_a = 0.10,
    sigma_logbeta_q = 0.30,
    sigma_logk_rep = 0.10,

    z_logdelta = rep(0, N_rt),
    z_logalpha = rep(0, N_rt),
    z_logbeta_a = rep(0, N_rt),
    z_logbeta_q = rep(0, N_rt),
    z_logk_rep = rep(0, N_rt),

    logk_abs_pop = log(96),
    logk_cl_pop = log(19.2),
    logk_repi_pop = log(0.04),

    sigma_logk_abs = 0.10,
    sigma_logk_cl = 0.10,
    sigma_logk_repi = 0.10,

    z_logk_abs = rep(0, N_comb),
    z_logk_cl = rep(0, N_comb),
    z_logk_repi = rep(0, N_comb),

    sigma = 0.20
  )
}

############################################################
# 13. Threaded smoke test
############################################################

if (MODE == "smoke") {

  cat("\n===== STAGE 4 THREADED SMOKE TEST =====\n")
  cat("1 chain x 4 threads; 20 warmup + 20 sampling.\n")

  smoke_timing <- system.time({
    fit <- mod$sample(
      data = stan_data,
      chains = 1,
      parallel_chains = 1,
      threads_per_chain = 4,
      iter_warmup = 20,
      iter_sampling = 20,
      adapt_delta = 0.95,
      max_treedepth = 12,
      seed = 123,
      init = stage4_init,
      output_dir = csv_dir,
      output_basename = "stage4new_mfull_exp_reducesum_smoke",
      refresh = 1
    )
  })

  print(smoke_timing)
  print(fit$diagnostic_summary())

  smoke_summary <- fit$summary(
    variables = c(
      "logV0_pop", "logr_pop",
      "logdelta_pop", "logalpha_pop",
      "logbeta_a_pop", "logbeta_q_pop",
      "logk_rep_pop",
      "logk_abs_pop", "logk_cl_pop", "logk_repi_pop",
      "sigma_logk_abs", "sigma_logk_cl", "sigma_logk_repi",
      "sigma"
    )
  )

  print(smoke_summary)

  write.csv(
    as.data.frame(fit$diagnostic_summary()),
    file.path(results_dir, "smoke_hmc_diagnostics.csv"),
    row.names = FALSE
  )

  write.csv(
    as.data.frame(smoke_summary),
    file.path(results_dir, "smoke_parameter_summary.csv"),
    row.names = FALSE
  )

  cat("\nSTAGE 4 THREADED SMOKE TEST COMPLETE.\n")
  quit(save = "no", status = 0)
}

############################################################
# 14. Full Stage-4 fit
############################################################

cat("\n===== STAGE 4 FULL THREADED FIT =====\n")
cat("4 chains x 4 threads = 16 requested cores.\n")
cat("500 warmup + 1000 sampling per chain.\n")

full_timing <- system.time({
  fit <- mod$sample(
    data = stan_data,
    chains = 4,
    parallel_chains = 4,
    threads_per_chain = 4,
    iter_warmup = 500,
    iter_sampling = 1000,
    adapt_delta = 0.99,
    max_treedepth = 12,
    seed = 123,
    init = stage4_init,
    output_dir = csv_dir,
    output_basename = "stage4new_mfull_exp_reducesum_full",
    refresh = 25
  )
})

print(full_timing)

############################################################
# 15. Immediate numerical diagnostics
############################################################

hmc_diag <- fit$diagnostic_summary()
print(hmc_diag)

write.csv(
  as.data.frame(hmc_diag),
  file.path(results_dir, "hmc_diagnostic_summary.csv"),
  row.names = FALSE
)

summary_vars <- c(
  "logV0_pop", "logr_pop",
  "logdelta_pop", "logalpha_pop",
  "logbeta_a_pop", "logbeta_q_pop",
  "logk_rep_pop",
  "sigma_logV0", "sigma_logr",
  "sigma_logdelta", "sigma_logalpha",
  "sigma_logbeta_a", "sigma_logbeta_q",
  "sigma_logk_rep",
  "logk_abs_pop", "logk_cl_pop", "logk_repi_pop",
  "sigma_logk_abs", "sigma_logk_cl", "sigma_logk_repi",
  "k_abs_comb", "k_cl_comb", "k_repi_comb",
  "sigma"
)

param_summary <- fit$summary(
  variables = summary_vars
)

print(param_summary)

write.csv(
  as.data.frame(param_summary),
  file.path(results_dir, "population_parameter_summary.csv"),
  row.names = FALSE
)

fit$save_object(
  file.path(results_dir, "fit_stage4NEW_exp_reducesum.rds")
)

cat("\nSTAGE 4 MFULL EXPONENTIAL REDUCE_SUM FULL FIT COMPLETE.\n")
